from typing import List

Elem = float | complex | int
Array = List
Array2D = List[Array]
